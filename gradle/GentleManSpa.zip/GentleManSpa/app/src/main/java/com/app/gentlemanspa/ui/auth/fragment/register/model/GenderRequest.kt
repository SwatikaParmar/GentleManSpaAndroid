package com.app.gentlemanspa.ui.auth.fragment.register.model

data class GenderRequest(var id :Int,var name: String)
