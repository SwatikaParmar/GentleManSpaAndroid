package com.app.gentlemanspa.ui.professionalDashboard.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.app.gentlemanspa.R
import com.app.gentlemanspa.databinding.ActivityProfessionalBinding

class ProfessionalActivity : AppCompatActivity() {
    private lateinit var binding : ActivityProfessionalBinding
    private lateinit var navController: NavController
    private lateinit var navHost: NavHostFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfessionalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initUI()

    }

    private fun initUI() {
        navHost = supportFragmentManager.findFragmentById(R.id.professionalContainer) as NavHostFragment
        navController = navHost.navController
        setBottomNavigation()
    }

    private fun setBottomNavigation() {
        binding.bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> {
                    navController.navigate(R.id.homeProfessionalFragment)
                    true
                }

                R.id.cart -> {
                   // navController.navigate(R.id.myAppointmentFragment)
                    true
                }

                R.id.history -> {
                   // navController.navigate(R.id.notificationFragment)
                    true
                }

                R.id.profile -> {
                    navController.navigate(R.id.profileProfessionalFragment)
                    true
                }

                else -> false
            }
        }
    }

    fun isDrawer(isBoolean: Boolean) {
        if (isBoolean) {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }
    }
}