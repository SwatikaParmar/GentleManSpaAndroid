package com.app.gentlemanspa.ui.customerDashboard.fragment.home.model

import kotlinx.parcelize.Parcelize
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

@Parcelize
data class BannerResponse(

	@field:SerializedName("data")
	val data: ArrayList<BannerItem>? = null,

	@field:SerializedName("messages")
	val messages: String? = null,

	@field:SerializedName("statusCode")
	val statusCode: Int? = null,

	@field:SerializedName("isSuccess")
	val isSuccess: Boolean? = null
) : Parcelable

@Parcelize
data class BannerItem(

	@field:SerializedName("bannerImage")
	val bannerImage: String? = null,

	@field:SerializedName("bannerType")
	val bannerType: String? = null,

	@field:SerializedName("modifyDate")
	val modifyDate: String? = null,

	@field:SerializedName("bannerId")
	val bannerId: Int? = null,

	@field:SerializedName("spaDetailId")
	val spaDetailId: Int? = null,

	@field:SerializedName("categoryId")
	val categoryId: Int? = null,

	@field:SerializedName("createDate")
	val createDate: String? = null
) : Parcelable
