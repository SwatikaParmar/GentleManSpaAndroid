package com.app.gentlemanspa.ui.customerDashboard.fragment.home.model

import kotlinx.parcelize.Parcelize
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

@Parcelize
data class CategoriesResponse(

    @field:SerializedName("data")
	val data: ArrayList<CategoriesItem>? = null,

    @field:SerializedName("messages")
	val messages: String? = null,

    @field:SerializedName("statusCode")
	val statusCode: Int? = null,

    @field:SerializedName("isSuccess")
	val isSuccess: Boolean? = null
) : Parcelable

@Parcelize
data class CategoriesItem(

	@field:SerializedName("categoryImage")
	val categoryImage: String? = null,

	@field:SerializedName("categoryStatus")
	val categoryStatus: Boolean? = null,

	@field:SerializedName("categoryName")
	val categoryName: String? = null,

	@field:SerializedName("categoryId")
	val categoryId: Int? = null,

	@field:SerializedName("categoryDescription")
	val categoryDescription: String? = null,

	@field:SerializedName("genderType")
	val genderType: String? = null
) : Parcelable
