package com.app.gentlemanspa.ui.professionalDashboard.fragment.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.gentlemanspa.R
import com.app.gentlemanspa.databinding.FragmentHomeProfessionalBinding
import com.app.gentlemanspa.ui.customerDashboard.activity.CustomerActivity
import com.app.gentlemanspa.ui.professionalDashboard.activity.ProfessionalActivity


class HomeProfessionalFragment : Fragment(), View.OnClickListener {
    private lateinit var binding : FragmentHomeProfessionalBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHomeProfessionalBinding.inflate(layoutInflater,container, false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUI()
    }

    private fun initUI() {
        binding.ivDrawer.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v) {
            binding.ivDrawer -> {
                (activity as ProfessionalActivity).isDrawer(true)
            }
        }
    }


}