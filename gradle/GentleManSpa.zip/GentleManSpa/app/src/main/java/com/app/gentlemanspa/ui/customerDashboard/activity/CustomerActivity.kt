package com.app.gentlemanspa.ui.customerDashboard.activity

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.app.gentlemanspa.R
import com.app.gentlemanspa.databinding.ActivityCustomerBinding

class CustomerActivity : AppCompatActivity() {
    private lateinit var binding : ActivityCustomerBinding
    private lateinit var navController: NavController
    private lateinit var navHost: NavHostFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initUI()

    }

    private fun initUI() {
        navHost = supportFragmentManager.findFragmentById(R.id.customerContainer) as NavHostFragment
        navController = navHost.navController
        setBottomNavigation()
    }

    private fun setBottomNavigation() {
        binding.bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> {
                    navController.navigate(R.id.homeCustomerFragment)
                    true
                }

                R.id.cart -> {
                    // navController.navigate(R.id.myAppointmentFragment)
                    true
                }

                R.id.history -> {
                    // navController.navigate(R.id.notificationFragment)
                    true
                }

                R.id.profile -> {
                   // navController.navigate(R.id.profileProfessionalFragment)
                    true
                }

                else -> false
            }
        }
    }


    fun isDrawer(isBoolean: Boolean) {
        if (isBoolean) {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }
    }
}