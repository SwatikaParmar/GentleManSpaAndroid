package com.app.gentlemanspa.ui.customerDashboard.fragment.home.model

import kotlinx.parcelize.Parcelize
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

@Parcelize
data class LocationResponse(

	@field:SerializedName("data")
	val data: ArrayList<LocationItem>? = null,

	@field:SerializedName("messages")
	val messages: String? = null,

	@field:SerializedName("statusCode")
	val statusCode: Int? = null,

	@field:SerializedName("isSuccess")
	val isSuccess: Boolean? = null
) : Parcelable

@Parcelize
data class LocationItem(

	@field:SerializedName("pincode")
	val pincode: String? = null,

	@field:SerializedName("country")
	val country: String? = null,

	@field:SerializedName("city")
	val city: String? = null,

	@field:SerializedName("address2")
	val address2: String? = null,

	@field:SerializedName("address1")
	val address1: String? = null,

	@field:SerializedName("phoneNumber1")
	val phoneNumber1: String? = null,

	@field:SerializedName("phoneNumber2")
	val phoneNumber2: String? = null,

	@field:SerializedName("password")
	val password: String? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("spaDetailId")
	val spaDetailId: Int? = null,

	@field:SerializedName("state")
	val state: String? = null,

	@field:SerializedName("landmark")
	val landmark: String? = null,

	@field:SerializedName("email")
	val email: String? = null
) : Parcelable
