package com.app.gentlemanspa.network

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}